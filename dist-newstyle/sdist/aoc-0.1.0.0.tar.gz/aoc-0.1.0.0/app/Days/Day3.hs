module Days.Day3 where

import Data.List (intersect)
import Data.List.Unique (unique)

compartments :: [Char] -> ([Char], [Char])
compartments rucksack = (first, last)
  where
    perCompartment = length rucksack `div` 2
    first = take perCompartment rucksack
    last = reverse $ take perCompartment $ reverse rucksack

bothCompartments :: ([Char], [Char]) -> [Char]
bothCompartments (first, second) = unique $ first `intersect` second

part1 :: [[Char]] -> IO ()
part1 lines =
  do
    print $ map (bothCompartments . compartments) lines

part2 lines =
  do
    print "Day 3 - Part 2"
